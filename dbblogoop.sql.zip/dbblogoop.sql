-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 01 feb 2022 om 09:57
-- Serverversie: 5.7.31
-- PHP-versie: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Web Design'),
(2, 'HTML'),
(3, 'CSS'),
(4, 'Freebies'),
(5, 'Bootstrap'),
(6, 'Vue'),
(7, 'Javascript');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `author`, `body`) VALUES
(1, 2, 'Tom', 'lorem ipsum'),
(9, 2, 'dsfdsfdfs', 'dsfdsf'),
(11, 2, 'dsfdf', 'dsfdsf');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `filename`, `alternate_text`, `type`, `size`) VALUES
(2, 'test', 'test', 'wolverine.png', '', 'jpg', 35),
(3, 'anonymous', 'We are legion, we don\'t forget, we don\'t forgive.', 'anonymous-1.jpg', 'anonymous hacker photo', 'image/jpeg', 17895),
(4, 'test', '<p>test</p>', 'logo-fsd-web.svg', 'test', 'image/svg+xml', 2002),
(6, 'sdfdsf', 'dsfds', 'MainDark.png', 'sdfd', 'image/png', 779955),
(7, 'dfdsf', 'sdfdsf', 'MainDark.png', 'dsfds', 'image/png', 779955),
(8, 'fff', 'fff', 'MainDark.png', 'fff', 'image/png', 779955),
(9, 'test', 'test', 'MainDark.png', 'test', 'image/png', 779955),
(10, 'test', 'test', 'MainDark.png', 'test', 'image/png', 779955),
(11, 'sdffds', 'sdfds', 'MainDark.png', 'dsfsd', 'image/png', 779955),
(12, 'dsfdsfsdfdsf', 'sdfdsfds', 'MainDark.png', 'dsfdfssdf', 'image/png', 779955),
(13, 'dsfsdf', 'dsfds', 'thor2022_01_27-10-52-44.png', 'dsfds', 'image/png', 66476),
(14, 'voorbeeld1', 'voorbeeld1', 'thor2022_01_31-08-41-26.jpg', 'voorbeeld1', 'image/jpeg', 53606),
(15, 'sdfsdf', 'dsfdsf', 'wolverinea2022_01_31-13-28-42.png', 'dsfds', 'image/png', 12479);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos_categories`
--

DROP TABLE IF EXISTS `photos_categories`;
CREATE TABLE IF NOT EXISTS `photos_categories` (
  `photo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos_categories`
--

INSERT INTO `photos_categories` (`photo_id`, `category_id`) VALUES
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(12, 3),
(12, 4),
(13, 1),
(13, 2),
(13, 3),
(14, 1),
(14, 5),
(14, 6),
(15, 1),
(15, 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`) VALUES
(1, 'Toppie', '12345678', 'Tom', 'Vanhoutte', 'hulk.png'),
(2, 'Thor', '12345678', 'lalalalall', 'Lustenhower', 'thor.png'),
(4, 'Tim', '12345678', 'Tim', 'Vanhoutte', ''),
(5, 'Sam', '123', 'Sam', 'Woef', ''),
(6, 'Sam', '123', 'Sam', 'Woef', ''),
(7, 'Sam', '123', 'Sam', 'Woef', ''),
(8, 'Sam', '123', 'Sam', 'Woef', ''),
(9, 'Sam', '123', 'Sam', 'Woef', ''),
(10, 'Sam', '123', 'Sam', 'Woef', ''),
(11, 'Sam', '123', 'Sam', 'Woef', ''),
(12, 'Sam', '123', 'Sam', 'Woef', ''),
(13, 'Sam', '123', 'Sam', 'Woef', ''),
(14, 'Sam', '123', 'Sam', 'Woef', ''),
(15, 'Sam', '123', 'Sam', 'Woef', ''),
(16, 'Sam', '123', 'Sam', 'Woef', ''),
(17, 'Sam', '123', 'Sam', 'Woef', ''),
(19, 'abc', 'abc', 'bac', 'tbaest', ''),
(20, 'abcd', 'abcd', 'bacd', 'tbaestd', ''),
(21, 'laatstetest', 'laatstetest', 'laatstetest', 'laatstetest', 'wolverine.png'),
(22, 'dsfdsffsddfds', 'dsfdsdfs', 'sdfdsfdfs', 'dsfdsf', 'captainamericaaaa2022_01_21-14-26-06.png'),
(23, 'dfkldsfds', 'dsfkldsjf', 'dsfkldsflk', 'sdfkldsfjkl', 'captainamericaaaaa2022_01_24-09-27-26.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
